# [PikeAdmin](https://www.pikeadmin.com) 

**PikeAdmin - FREE Bootstrap 4 Admin Dashboard Template.**

Pike Admin is a clean and modern admin template built with Bootstrap 4. It stands out with its clean design and elegant typography. Pike Admin Free edition is completely free to download and use for your personal or commercial projects.

![Design Blocks](https://www.pikeadmin.com/assets/img/pike-bootstrap4-admin-template.jpg)

## Main features:

- Full Responsive Design
- Fast and Lightweight
- Modern design
- Completely free to download and use for your personal or commercial projects.

## Dozens of pages, components and plugins available in free edition:

- Charts
- Calendar
- Fancybox
- Multiple files uploads
- Form validation
- Text Editor
- Google Maps
- Star Rating
- Range Sliders
- Tree View
- Date-time Picker
- Color Picker
- Multimedia:
- Masonry
- Lightbox
- Owl carousel
- Image magnifier
- Font Awesome Icons

**More details, demo and download here: [PikeAdmin](https://www.pikeadmin.com)  **
